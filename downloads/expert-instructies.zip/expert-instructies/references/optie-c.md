# Optie C - Sparringpartner

## Wat je doet

De gebruiker wil de expert als gesprekspartner gebruiken. Dit kan eenmalig zijn of structureel.

## Stap 1: Eenmalig of structureel?

Vraag: "Ga je deze expert eenmalig gebruiken voor een specifiek vraagstuk, of wil je hem vaker kunnen inzetten?"

## Route: Eenmalig

Vraag eerst: "Wat verwacht je van de expert? Uitdagen, problemen zoeken, adviseren, meedenken, of een combinatie?"

Schakel daarna direct over naar de expert persona in het huidige gesprek. De gebruiker beschrijft zijn vraagstuk en de expert gaat het gesprek aan.

"Als je een ander soort expert nodig hebt, weet je me te vinden."

## Route: Structureel

Vraag: "Wil je deze expert voor een specifiek doel gebruiken, of voor verschillende soorten vragen en vraagstukken?"

### Specifiek doel -> Skill bouwen

1. Vraag door naar het doel en hoe de expert daarbij kan helpen. Stel genoeg vragen tot je helder hebt wat de skill moet doen.

2. Vraag: "Zijn er documenten of kennisbronnen die de expert moet kennen? Je kunt deze ook later nog toevoegen." Als ja, vraag door: "Hoe moet de expert deze documenten gebruiken? Als naslagwerk, als bron, als voorbeeld, of iets anders?"

3. Vraag: "Hoe wil je deze skill noemen?"

4. Vraag: "Mag ik deze skill zelf inzetten als ik denk dat het relevant is, of wil je hem alleen gebruiken als je er specifiek om vraagt?"

5. Bouw de skill met behulp van de skill-creator. De expert persona is de basis, de skill-instructies bepalen wanneer en hoe de expert wordt ingezet. Verwerk de documentinstructies in de skill.

### Algemeen gebruik

1. Achterhaal hoe de expert zich moet gedragen. Vraag:
   - "Hoe moet de expert je uitdagen? Kritisch op alles, creatief meedenken, meer begeleidend en lerend, of een mix?"

2. Vraag: "Is er specifieke kennis die de expert moet hebben? Documenten, handleidingen, procedures? Je kunt deze ook later nog toevoegen." Als ja, vraag door: "Hoe moet de expert deze documenten gebruiken? Als naslagwerk om antwoorden op te baseren, als bron om uit te citeren, als context, of iets anders?" Verwerk dit in de instructies.

3. Beoordeel of een skill of een project beter past:
   - **Skill**: als de expert een duidelijke trigger heeft en Claude hem automatisch kan inzetten op het juiste moment
   - **Project**: als de gebruiker een vaste plek wil waar ze naartoe gaan voor dit type gesprek, of als er veel kennisdocumenten bij komen

   Als een project beter zou zijn, zeg dit en vraag of de gebruiker dat liever wil.

   - Kiest de gebruiker **project**: lees `/mnt/skills/user/expert-instructies/references/optie-b.md` met de view tool en volg die instructies vanaf stap 1
   - Kiest de gebruiker **skill**: vraag de naam, vraag of auto-trigger of handmatig, en bouw via skill-creator

4. Afsluiten: "Als je een ander soort expert nodig hebt, weet je me te vinden."
